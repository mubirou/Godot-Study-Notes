// Roulette.cs
using Godot;

public class Roulette : Sprite {
    private float _rotSpeed = 0f; // 回転速度

    // 繰り返し実行される
    public override void _Process(float _delta) {
        // 回転速度ぶんルーレットを回転させる
		Rotation += _rotSpeed;
		_rotSpeed *= 0.98f; // ルーレットを減速させる
    }

	// マウスが押されたら回転速度を設定する
    public override void _Input(InputEvent _event) {
        if (_event is InputEventMouseButton _mouseEvent) {
            if (_mouseEvent.ButtonIndex == 1) { // 左ボタン
                if (_mouseEvent.Pressed) {
					_rotSpeed = 3f;
                }
			}
		}
	}
}


/*
// Roullette.cs
using Godot;

public class Roullette : Node2D {
	private int _rotSpeed = 0; // 回転速度

	public override void _Ready() {
		GD.Print("Rotation");
	}

	// 繰り返し実行される
	public override void _Process(float _delta) {
		GD.Print(_delta); //-> 0.006944444
	}
}


/*
# Roullette.gd
extends Sprite

var _rotSpeed = 0 # 回転速度
	
func _process(_delta): # 繰り返し実行
	# 回転速度ぶんルーレットを回転させる
	rotation += _rotSpeed
	_rotSpeed *= 0.98 # ルーレットを減速させる

# マウスが押されたら回転速度を設定する
func _input(_event): # 入力イベント
	if _event is InputEventMouseButton: # マウスを押したら
		if _event.button_index == 1: # マウスの左ボタン
			if _event.pressed: # 押している
				_rotSpeed = 3;

*/