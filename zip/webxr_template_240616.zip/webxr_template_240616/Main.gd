# Main.gd
extends Node3D

func _ready() -> void:
	Debug.print("Hello VR World")

func _on_right_controller_button_pressed(name):
	Debug.print("something")
