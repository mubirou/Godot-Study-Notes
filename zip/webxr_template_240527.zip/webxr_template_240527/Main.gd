# Main.gd
extends Node3D

var _webxr_manager: WebXRManager
var _debugger: Label3D  # Debugger

func _ready() -> void:
	_webxr_manager = WebXRManager.new(self)
	
	# Debugger
	_debugger = $XROrigin3D/RightController/Debugger
	_debugger.print("Hello World")

func _process(delta: float) -> void:
	pass

func _on_right_controller_button_pressed(name):
	_debugger.print("hoge")
	#_debugger.reset()  # Debugger（出力をクリア）
