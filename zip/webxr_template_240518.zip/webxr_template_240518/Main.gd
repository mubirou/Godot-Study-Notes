# Main.gd
extends Node3D

const WebXRManager = preload("res://WebXRManager.gd")
var _webxr_manager: WebXRManager
var _debugger: Label3D # Debugger

func _ready() -> void:
	_webxr_manager = WebXRManager.new(self)
	_debugger = get_node("/root/Main/XROrigin3D/RightController/Debugger") # Debugger
	_debugger.print("Hello World") # Debugger

func _process(delta: float) -> void:
	pass

func _on_right_controller_button_pressed(name):
	_debugger.reset() # Debugger（出力をクリア）
