# Main.gd
extends Node3D

var _webxr_manager: WebXRManager

func _ready() -> void:
	_webxr_manager = WebXRManager.new(self)
	Debug.print("Hello World")

func _process(delta: float) -> void:
	pass

func _on_right_controller_button_pressed(name):
	Debug.print("hoge")
	#Debug.reset()  # Debug（出力をクリア）
	pass
